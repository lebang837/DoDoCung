﻿namespace DoDoCung
{
    partial class frmDDC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabSelect = new System.Windows.Forms.TabControl();
            this.tabMain = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.tbOk = new System.Windows.Forms.TextBox();
            this.NGMaxMin = new System.Windows.Forms.TextBox();
            this.tbNG = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.cbMahangrun = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.cbLot = new System.Windows.Forms.ComboBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.lbKq_R3 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lbKq_R2 = new System.Windows.Forms.Label();
            this.tbKetquaR1 = new System.Windows.Forms.TextBox();
            this.lbKq_R1 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tbKetquaR2 = new System.Windows.Forms.TextBox();
            this.tbKetquaR3 = new System.Windows.Forms.TextBox();
            this.lbKetquaR = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.tbTrungbinhR = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tbKetquaL1 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.tbKetquaL2 = new System.Windows.Forms.TextBox();
            this.lbKq_L3 = new System.Windows.Forms.Label();
            this.tbKetquaL3 = new System.Windows.Forms.TextBox();
            this.lbKq_L2 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.lbKq_L1 = new System.Windows.Forms.Label();
            this.tbTrungbinhL = new System.Windows.Forms.TextBox();
            this.lbKetquaL = new System.Windows.Forms.Label();
            this.btTest = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbDD1status = new System.Windows.Forms.Label();
            this.lbDD2status = new System.Windows.Forms.Label();
            this.lbDD3status = new System.Windows.Forms.Label();
            this.lbDD4status = new System.Windows.Forms.Label();
            this.lbDD5status = new System.Windows.Forms.Label();
            this.lbDD6status = new System.Windows.Forms.Label();
            this.lbPLCstatus = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tbMinD3_Main = new System.Windows.Forms.TextBox();
            this.tbMaxD3_Main = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.tbMinD2_Main = new System.Windows.Forms.TextBox();
            this.tbMaxD2_Main = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.tbMinD1_Main = new System.Windows.Forms.TextBox();
            this.tbMaxD1_Main = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.tabSpec = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.txb_MaHangMoi = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.grSpec = new System.Windows.Forms.GroupBox();
            this.Chb_ChekcMau = new System.Windows.Forms.CheckBox();
            this.label41 = new System.Windows.Forms.Label();
            this.btSavespec = new System.Windows.Forms.Button();
            this.cbSodiemdo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbSellectMax_Min = new System.Windows.Forms.CheckBox();
            this.tbMax_Min = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSpecMinD3 = new System.Windows.Forms.TextBox();
            this.tbSpecMaxD3 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tbSpecMinD2 = new System.Windows.Forms.TextBox();
            this.tbSpecMaxD2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tbSpecMinD1 = new System.Windows.Forms.TextBox();
            this.tbSpecMaxD1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.cbMahangSet = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.btSaveST = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cbBaudrateR3 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cbComR3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbBaudrateL3 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbComL3 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cbBaudrateR2 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cbComR2 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbBaudrateL2 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbComL2 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.cbBaudrateR1 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cbComR1 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.grb_PLC = new System.Windows.Forms.GroupBox();
            this.btCheckconnect = new System.Windows.Forms.Button();
            this.tbPortplc = new System.Windows.Forms.TextBox();
            this.tbIPplc = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbBaudrateL1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cbComL1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.tabSelect.SuspendLayout();
            this.tabMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabSpec.SuspendLayout();
            this.grSpec.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.grb_PLC.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabSelect
            // 
            this.tabSelect.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabSelect.Controls.Add(this.tabMain);
            this.tabSelect.Controls.Add(this.tabSpec);
            this.tabSelect.Controls.Add(this.tabPage1);
            this.tabSelect.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSelect.Location = new System.Drawing.Point(1, 50);
            this.tabSelect.Name = "tabSelect";
            this.tabSelect.SelectedIndex = 0;
            this.tabSelect.Size = new System.Drawing.Size(1883, 911);
            this.tabSelect.TabIndex = 25;
            this.tabSelect.SelectedIndexChanged += new System.EventHandler(this.tabSelect_SelectedIndexChanged);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.dataGridView1);
            this.tabMain.Controls.Add(this.groupBox11);
            this.tabMain.Controls.Add(this.groupBox10);
            this.tabMain.Controls.Add(this.groupBox9);
            this.tabMain.Controls.Add(this.groupBox8);
            this.tabMain.Controls.Add(this.btTest);
            this.tabMain.Controls.Add(this.panel1);
            this.tabMain.Controls.Add(this.groupBox7);
            this.tabMain.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMain.Location = new System.Drawing.Point(4, 26);
            this.tabMain.Name = "tabMain";
            this.tabMain.Padding = new System.Windows.Forms.Padding(3);
            this.tabMain.Size = new System.Drawing.Size(1875, 881);
            this.tabMain.TabIndex = 0;
            this.tabMain.Text = "Main";
            this.tabMain.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(875, 244);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(987, 489);
            this.dataGridView1.TabIndex = 137;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label43);
            this.groupBox11.Controls.Add(this.label36);
            this.groupBox11.Controls.Add(this.label29);
            this.groupBox11.Controls.Add(this.label39);
            this.groupBox11.Controls.Add(this.tbTotal);
            this.groupBox11.Controls.Add(this.tbOk);
            this.groupBox11.Controls.Add(this.NGMaxMin);
            this.groupBox11.Controls.Add(this.tbNG);
            this.groupBox11.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(1474, 12);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(388, 214);
            this.groupBox11.TabIndex = 136;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Tổng Hợp Kết Quả";
            // 
            // label43
            // 
            this.label43.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(21, 168);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(166, 27);
            this.label43.TabIndex = 103;
            this.label43.Text = "NG Chênh Lệch";
            // 
            // label36
            // 
            this.label36.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Red;
            this.label36.Location = new System.Drawing.Point(21, 122);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(166, 27);
            this.label36.TabIndex = 101;
            this.label36.Text = "NG Giá Trị";
            // 
            // label29
            // 
            this.label29.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label29.Location = new System.Drawing.Point(21, 86);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(166, 27);
            this.label29.TabIndex = 100;
            this.label29.Text = "OK";
            // 
            // label39
            // 
            this.label39.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(21, 47);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(166, 27);
            this.label39.TabIndex = 90;
            this.label39.Text = "Tổng Số Lượng";
            // 
            // tbTotal
            // 
            this.tbTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbTotal.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTotal.Location = new System.Drawing.Point(205, 39);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.Size = new System.Drawing.Size(130, 29);
            this.tbTotal.TabIndex = 95;
            // 
            // tbOk
            // 
            this.tbOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbOk.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbOk.Location = new System.Drawing.Point(205, 88);
            this.tbOk.Name = "tbOk";
            this.tbOk.Size = new System.Drawing.Size(130, 29);
            this.tbOk.TabIndex = 96;
            // 
            // NGMaxMin
            // 
            this.NGMaxMin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.NGMaxMin.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NGMaxMin.Location = new System.Drawing.Point(205, 168);
            this.NGMaxMin.Name = "NGMaxMin";
            this.NGMaxMin.Size = new System.Drawing.Size(130, 29);
            this.NGMaxMin.TabIndex = 99;
            // 
            // tbNG
            // 
            this.tbNG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tbNG.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNG.Location = new System.Drawing.Point(205, 127);
            this.tbNG.Name = "tbNG";
            this.tbNG.Size = new System.Drawing.Size(130, 29);
            this.tbNG.TabIndex = 97;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label28);
            this.groupBox10.Controls.Add(this.cbMahangrun);
            this.groupBox10.Controls.Add(this.label44);
            this.groupBox10.Controls.Add(this.cbLot);
            this.groupBox10.Location = new System.Drawing.Point(3, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(430, 220);
            this.groupBox10.TabIndex = 135;
            this.groupBox10.TabStop = false;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(15, 38);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 24);
            this.label28.TabIndex = 68;
            this.label28.Text = "Mã Hàng:";
            // 
            // cbMahangrun
            // 
            this.cbMahangrun.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMahangrun.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMahangrun.FormattingEnabled = true;
            this.cbMahangrun.Location = new System.Drawing.Point(155, 34);
            this.cbMahangrun.Name = "cbMahangrun";
            this.cbMahangrun.Size = new System.Drawing.Size(255, 32);
            this.cbMahangrun.TabIndex = 69;
            this.cbMahangrun.SelectedIndexChanged += new System.EventHandler(this.cbMahangrun_SelectedIndexChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(15, 77);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(42, 22);
            this.label44.TabIndex = 100;
            this.label44.Text = "Lot:";
            // 
            // cbLot
            // 
            this.cbLot.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbLot.FormattingEnabled = true;
            this.cbLot.Location = new System.Drawing.Point(155, 74);
            this.cbLot.Name = "cbLot";
            this.cbLot.Size = new System.Drawing.Size(255, 32);
            this.cbLot.TabIndex = 101;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.lbKq_R3);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.lbKq_R2);
            this.groupBox9.Controls.Add(this.tbKetquaR1);
            this.groupBox9.Controls.Add(this.lbKq_R1);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.tbKetquaR2);
            this.groupBox9.Controls.Add(this.tbKetquaR3);
            this.groupBox9.Controls.Add(this.lbKetquaR);
            this.groupBox9.Controls.Add(this.label38);
            this.groupBox9.Controls.Add(this.tbTrungbinhR);
            this.groupBox9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(439, 232);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(430, 501);
            this.groupBox9.TabIndex = 134;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Kết Quả Sản Phẩm 2";
            // 
            // lbKq_R3
            // 
            this.lbKq_R3.BackColor = System.Drawing.SystemColors.Control;
            this.lbKq_R3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKq_R3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKq_R3.ForeColor = System.Drawing.Color.Green;
            this.lbKq_R3.Location = new System.Drawing.Point(357, 133);
            this.lbKq_R3.Name = "lbKq_R3";
            this.lbKq_R3.Size = new System.Drawing.Size(53, 29);
            this.lbKq_R3.TabIndex = 130;
            this.lbKq_R3.Text = "?";
            this.lbKq_R3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(17, 45);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(161, 22);
            this.label35.TabIndex = 79;
            this.label35.Text = "Giá Trị Điểm Đo 1";
            // 
            // lbKq_R2
            // 
            this.lbKq_R2.BackColor = System.Drawing.SystemColors.Control;
            this.lbKq_R2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKq_R2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKq_R2.ForeColor = System.Drawing.Color.Green;
            this.lbKq_R2.Location = new System.Drawing.Point(357, 88);
            this.lbKq_R2.Name = "lbKq_R2";
            this.lbKq_R2.Size = new System.Drawing.Size(53, 29);
            this.lbKq_R2.TabIndex = 129;
            this.lbKq_R2.Text = "?";
            this.lbKq_R2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbKetquaR1
            // 
            this.tbKetquaR1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKetquaR1.Location = new System.Drawing.Point(203, 41);
            this.tbKetquaR1.Name = "tbKetquaR1";
            this.tbKetquaR1.Size = new System.Drawing.Size(130, 29);
            this.tbKetquaR1.TabIndex = 77;
            // 
            // lbKq_R1
            // 
            this.lbKq_R1.BackColor = System.Drawing.SystemColors.Control;
            this.lbKq_R1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKq_R1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKq_R1.ForeColor = System.Drawing.Color.Green;
            this.lbKq_R1.Location = new System.Drawing.Point(357, 40);
            this.lbKq_R1.Name = "lbKq_R1";
            this.lbKq_R1.Size = new System.Drawing.Size(53, 29);
            this.lbKq_R1.TabIndex = 128;
            this.lbKq_R1.Text = "?";
            this.lbKq_R1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(17, 90);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(161, 22);
            this.label34.TabIndex = 80;
            this.label34.Text = "Giá Trị Điểm Đo 2";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(16, 135);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(161, 22);
            this.label33.TabIndex = 81;
            this.label33.Text = "Giá Trị Điểm Đo 3";
            // 
            // tbKetquaR2
            // 
            this.tbKetquaR2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKetquaR2.Location = new System.Drawing.Point(203, 88);
            this.tbKetquaR2.Name = "tbKetquaR2";
            this.tbKetquaR2.Size = new System.Drawing.Size(130, 29);
            this.tbKetquaR2.TabIndex = 82;
            // 
            // tbKetquaR3
            // 
            this.tbKetquaR3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKetquaR3.Location = new System.Drawing.Point(203, 133);
            this.tbKetquaR3.Name = "tbKetquaR3";
            this.tbKetquaR3.Size = new System.Drawing.Size(130, 29);
            this.tbKetquaR3.TabIndex = 83;
            // 
            // lbKetquaR
            // 
            this.lbKetquaR.BackColor = System.Drawing.SystemColors.Control;
            this.lbKetquaR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKetquaR.Font = new System.Drawing.Font("Arial", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKetquaR.ForeColor = System.Drawing.Color.Green;
            this.lbKetquaR.Location = new System.Drawing.Point(22, 357);
            this.lbKetquaR.Name = "lbKetquaR";
            this.lbKetquaR.Size = new System.Drawing.Size(388, 125);
            this.lbKetquaR.TabIndex = 85;
            this.lbKetquaR.Text = "?";
            this.lbKetquaR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(17, 179);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(162, 22);
            this.label38.TabIndex = 88;
            this.label38.Text = "Giá Trị Trung Bình";
            // 
            // tbTrungbinhR
            // 
            this.tbTrungbinhR.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTrungbinhR.Location = new System.Drawing.Point(203, 176);
            this.tbTrungbinhR.Name = "tbTrungbinhR";
            this.tbTrungbinhR.Size = new System.Drawing.Size(130, 29);
            this.tbTrungbinhR.TabIndex = 89;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.tbKetquaL1);
            this.groupBox8.Controls.Add(this.label30);
            this.groupBox8.Controls.Add(this.label31);
            this.groupBox8.Controls.Add(this.label32);
            this.groupBox8.Controls.Add(this.tbKetquaL2);
            this.groupBox8.Controls.Add(this.lbKq_L3);
            this.groupBox8.Controls.Add(this.tbKetquaL3);
            this.groupBox8.Controls.Add(this.lbKq_L2);
            this.groupBox8.Controls.Add(this.label37);
            this.groupBox8.Controls.Add(this.lbKq_L1);
            this.groupBox8.Controls.Add(this.tbTrungbinhL);
            this.groupBox8.Controls.Add(this.lbKetquaL);
            this.groupBox8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(3, 232);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(430, 501);
            this.groupBox8.TabIndex = 133;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Kết Quả Sản Phẩm 1";
            // 
            // tbKetquaL1
            // 
            this.tbKetquaL1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKetquaL1.Location = new System.Drawing.Point(205, 41);
            this.tbKetquaL1.Name = "tbKetquaL1";
            this.tbKetquaL1.Size = new System.Drawing.Size(130, 29);
            this.tbKetquaL1.TabIndex = 70;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(18, 45);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(161, 22);
            this.label30.TabIndex = 72;
            this.label30.Text = "Giá Trị Điểm Đo 1";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(18, 89);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(161, 22);
            this.label31.TabIndex = 73;
            this.label31.Text = "Giá Trị Điểm Đo 2";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(17, 132);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(161, 22);
            this.label32.TabIndex = 74;
            this.label32.Text = "Giá Trị Điểm Đo 3";
            // 
            // tbKetquaL2
            // 
            this.tbKetquaL2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKetquaL2.Location = new System.Drawing.Point(205, 86);
            this.tbKetquaL2.Name = "tbKetquaL2";
            this.tbKetquaL2.Size = new System.Drawing.Size(130, 29);
            this.tbKetquaL2.TabIndex = 75;
            // 
            // lbKq_L3
            // 
            this.lbKq_L3.BackColor = System.Drawing.SystemColors.Control;
            this.lbKq_L3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKq_L3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKq_L3.ForeColor = System.Drawing.Color.Green;
            this.lbKq_L3.Location = new System.Drawing.Point(357, 130);
            this.lbKq_L3.Name = "lbKq_L3";
            this.lbKq_L3.Size = new System.Drawing.Size(53, 29);
            this.lbKq_L3.TabIndex = 127;
            this.lbKq_L3.Text = "?";
            this.lbKq_L3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbKetquaL3
            // 
            this.tbKetquaL3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKetquaL3.Location = new System.Drawing.Point(205, 130);
            this.tbKetquaL3.Name = "tbKetquaL3";
            this.tbKetquaL3.Size = new System.Drawing.Size(130, 29);
            this.tbKetquaL3.TabIndex = 76;
            // 
            // lbKq_L2
            // 
            this.lbKq_L2.BackColor = System.Drawing.SystemColors.Control;
            this.lbKq_L2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKq_L2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKq_L2.ForeColor = System.Drawing.Color.Green;
            this.lbKq_L2.Location = new System.Drawing.Point(357, 86);
            this.lbKq_L2.Name = "lbKq_L2";
            this.lbKq_L2.Size = new System.Drawing.Size(53, 29);
            this.lbKq_L2.TabIndex = 126;
            this.lbKq_L2.Text = "?";
            this.lbKq_L2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(17, 180);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(162, 22);
            this.label37.TabIndex = 86;
            this.label37.Text = "Giá Trị Trung Bình";
            // 
            // lbKq_L1
            // 
            this.lbKq_L1.BackColor = System.Drawing.SystemColors.Control;
            this.lbKq_L1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKq_L1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKq_L1.ForeColor = System.Drawing.Color.Green;
            this.lbKq_L1.Location = new System.Drawing.Point(357, 41);
            this.lbKq_L1.Name = "lbKq_L1";
            this.lbKq_L1.Size = new System.Drawing.Size(53, 29);
            this.lbKq_L1.TabIndex = 125;
            this.lbKq_L1.Text = "?";
            this.lbKq_L1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbTrungbinhL
            // 
            this.tbTrungbinhL.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTrungbinhL.Location = new System.Drawing.Point(206, 175);
            this.tbTrungbinhL.Name = "tbTrungbinhL";
            this.tbTrungbinhL.Size = new System.Drawing.Size(130, 29);
            this.tbTrungbinhL.TabIndex = 87;
            // 
            // lbKetquaL
            // 
            this.lbKetquaL.BackColor = System.Drawing.SystemColors.Control;
            this.lbKetquaL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbKetquaL.Font = new System.Drawing.Font("Arial", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbKetquaL.ForeColor = System.Drawing.Color.Green;
            this.lbKetquaL.Location = new System.Drawing.Point(19, 357);
            this.lbKetquaL.Name = "lbKetquaL";
            this.lbKetquaL.Size = new System.Drawing.Size(391, 125);
            this.lbKetquaL.TabIndex = 84;
            this.lbKetquaL.Text = "?";
            this.lbKetquaL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btTest
            // 
            this.btTest.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTest.Location = new System.Drawing.Point(1666, 758);
            this.btTest.Name = "btTest";
            this.btTest.Size = new System.Drawing.Size(203, 90);
            this.btTest.TabIndex = 132;
            this.btTest.Text = "Ấn F1 Để Đo";
            this.btTest.UseVisualStyleBackColor = true;
            this.btTest.Click += new System.EventHandler(this.btTest_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbDD1status);
            this.panel1.Controls.Add(this.lbDD2status);
            this.panel1.Controls.Add(this.lbDD3status);
            this.panel1.Controls.Add(this.lbDD4status);
            this.panel1.Controls.Add(this.lbDD5status);
            this.panel1.Controls.Add(this.lbDD6status);
            this.panel1.Controls.Add(this.lbPLCstatus);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 850);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1869, 28);
            this.panel1.TabIndex = 131;
            // 
            // lbDD1status
            // 
            this.lbDD1status.BackColor = System.Drawing.Color.Transparent;
            this.lbDD1status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDD1status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDD1status.Location = new System.Drawing.Point(1, 1);
            this.lbDD1status.Name = "lbDD1status";
            this.lbDD1status.Size = new System.Drawing.Size(109, 26);
            this.lbDD1status.TabIndex = 117;
            this.lbDD1status.Text = "DD1 Status";
            this.lbDD1status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDD2status
            // 
            this.lbDD2status.BackColor = System.Drawing.Color.Transparent;
            this.lbDD2status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDD2status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDD2status.Location = new System.Drawing.Point(109, 1);
            this.lbDD2status.Name = "lbDD2status";
            this.lbDD2status.Size = new System.Drawing.Size(109, 26);
            this.lbDD2status.TabIndex = 118;
            this.lbDD2status.Text = "DD2 Status";
            this.lbDD2status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDD3status
            // 
            this.lbDD3status.BackColor = System.Drawing.Color.Transparent;
            this.lbDD3status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDD3status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDD3status.Location = new System.Drawing.Point(217, 1);
            this.lbDD3status.Name = "lbDD3status";
            this.lbDD3status.Size = new System.Drawing.Size(109, 26);
            this.lbDD3status.TabIndex = 119;
            this.lbDD3status.Text = "DD3 Status";
            this.lbDD3status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDD4status
            // 
            this.lbDD4status.BackColor = System.Drawing.Color.Transparent;
            this.lbDD4status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDD4status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDD4status.Location = new System.Drawing.Point(325, 1);
            this.lbDD4status.Name = "lbDD4status";
            this.lbDD4status.Size = new System.Drawing.Size(109, 26);
            this.lbDD4status.TabIndex = 120;
            this.lbDD4status.Text = "DD4 Status";
            this.lbDD4status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDD5status
            // 
            this.lbDD5status.BackColor = System.Drawing.Color.Transparent;
            this.lbDD5status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDD5status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDD5status.Location = new System.Drawing.Point(433, 1);
            this.lbDD5status.Name = "lbDD5status";
            this.lbDD5status.Size = new System.Drawing.Size(109, 26);
            this.lbDD5status.TabIndex = 121;
            this.lbDD5status.Text = "DD5 Status";
            this.lbDD5status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbDD6status
            // 
            this.lbDD6status.BackColor = System.Drawing.Color.Transparent;
            this.lbDD6status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbDD6status.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDD6status.Location = new System.Drawing.Point(541, 1);
            this.lbDD6status.Name = "lbDD6status";
            this.lbDD6status.Size = new System.Drawing.Size(109, 26);
            this.lbDD6status.TabIndex = 122;
            this.lbDD6status.Text = "DD6 Status";
            this.lbDD6status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPLCstatus
            // 
            this.lbPLCstatus.BackColor = System.Drawing.Color.Transparent;
            this.lbPLCstatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPLCstatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPLCstatus.Location = new System.Drawing.Point(649, 1);
            this.lbPLCstatus.Name = "lbPLCstatus";
            this.lbPLCstatus.Size = new System.Drawing.Size(232, 26);
            this.lbPLCstatus.TabIndex = 123;
            this.lbPLCstatus.Text = "PLC Status";
            this.lbPLCstatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.tbMinD3_Main);
            this.groupBox7.Controls.Add(this.tbMaxD3_Main);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Controls.Add(this.tbMinD2_Main);
            this.groupBox7.Controls.Add(this.tbMaxD2_Main);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.label53);
            this.groupBox7.Controls.Add(this.label54);
            this.groupBox7.Controls.Add(this.tbMinD1_Main);
            this.groupBox7.Controls.Add(this.tbMaxD1_Main);
            this.groupBox7.Controls.Add(this.label55);
            this.groupBox7.Controls.Add(this.label56);
            this.groupBox7.Controls.Add(this.label57);
            this.groupBox7.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(436, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1032, 220);
            this.groupBox7.TabIndex = 124;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tiêu Chuẩn Đánh Giá";
            // 
            // tbMinD3_Main
            // 
            this.tbMinD3_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMinD3_Main.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMinD3_Main.Location = new System.Drawing.Point(776, 130);
            this.tbMinD3_Main.Name = "tbMinD3_Main";
            this.tbMinD3_Main.ReadOnly = true;
            this.tbMinD3_Main.Size = new System.Drawing.Size(128, 29);
            this.tbMinD3_Main.TabIndex = 81;
            // 
            // tbMaxD3_Main
            // 
            this.tbMaxD3_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMaxD3_Main.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMaxD3_Main.Location = new System.Drawing.Point(776, 74);
            this.tbMaxD3_Main.Name = "tbMaxD3_Main";
            this.tbMaxD3_Main.ReadOnly = true;
            this.tbMaxD3_Main.Size = new System.Drawing.Size(128, 29);
            this.tbMaxD3_Main.TabIndex = 80;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(626, 28);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(106, 22);
            this.label49.TabIndex = 77;
            this.label49.Text = "Điểm Đo 3:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(627, 74);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(131, 22);
            this.label50.TabIndex = 78;
            this.label50.Text = "Giới Hạn Trên:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(627, 133);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(136, 22);
            this.label51.TabIndex = 79;
            this.label51.Text = "Giới Hạn Dưới:";
            // 
            // tbMinD2_Main
            // 
            this.tbMinD2_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMinD2_Main.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMinD2_Main.Location = new System.Drawing.Point(460, 130);
            this.tbMinD2_Main.Name = "tbMinD2_Main";
            this.tbMinD2_Main.ReadOnly = true;
            this.tbMinD2_Main.Size = new System.Drawing.Size(128, 29);
            this.tbMinD2_Main.TabIndex = 76;
            // 
            // tbMaxD2_Main
            // 
            this.tbMaxD2_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMaxD2_Main.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMaxD2_Main.Location = new System.Drawing.Point(460, 74);
            this.tbMaxD2_Main.Name = "tbMaxD2_Main";
            this.tbMaxD2_Main.ReadOnly = true;
            this.tbMaxD2_Main.Size = new System.Drawing.Size(128, 29);
            this.tbMaxD2_Main.TabIndex = 75;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(315, 28);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(106, 22);
            this.label52.TabIndex = 72;
            this.label52.Text = "Điểm Đo 2:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(316, 74);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(131, 22);
            this.label53.TabIndex = 73;
            this.label53.Text = "Giới Hạn Trên:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(316, 133);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(136, 22);
            this.label54.TabIndex = 74;
            this.label54.Text = "Giới Hạn Dưới:";
            // 
            // tbMinD1_Main
            // 
            this.tbMinD1_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMinD1_Main.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMinD1_Main.Location = new System.Drawing.Point(165, 130);
            this.tbMinD1_Main.Name = "tbMinD1_Main";
            this.tbMinD1_Main.ReadOnly = true;
            this.tbMinD1_Main.Size = new System.Drawing.Size(128, 29);
            this.tbMinD1_Main.TabIndex = 71;
            // 
            // tbMaxD1_Main
            // 
            this.tbMaxD1_Main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbMaxD1_Main.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMaxD1_Main.Location = new System.Drawing.Point(165, 74);
            this.tbMaxD1_Main.Name = "tbMaxD1_Main";
            this.tbMaxD1_Main.ReadOnly = true;
            this.tbMaxD1_Main.Size = new System.Drawing.Size(128, 29);
            this.tbMaxD1_Main.TabIndex = 70;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(21, 28);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(106, 22);
            this.label55.TabIndex = 52;
            this.label55.Text = "Điểm Đo 1:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(22, 74);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(131, 22);
            this.label56.TabIndex = 68;
            this.label56.Text = "Giới Hạn Trên:";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(22, 133);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(136, 22);
            this.label57.TabIndex = 69;
            this.label57.Text = "Giới Hạn Dưới:";
            // 
            // tabSpec
            // 
            this.tabSpec.Controls.Add(this.txb_MaHangMoi);
            this.tabSpec.Controls.Add(this.label42);
            this.tabSpec.Controls.Add(this.grSpec);
            this.tabSpec.Controls.Add(this.cbMahangSet);
            this.tabSpec.Controls.Add(this.label11);
            this.tabSpec.Location = new System.Drawing.Point(4, 26);
            this.tabSpec.Name = "tabSpec";
            this.tabSpec.Padding = new System.Windows.Forms.Padding(3);
            this.tabSpec.Size = new System.Drawing.Size(1875, 881);
            this.tabSpec.TabIndex = 1;
            this.tabSpec.Text = "Spec";
            this.tabSpec.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Blue;
            this.button1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(905, 233);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 67);
            this.button1.TabIndex = 88;
            this.button1.Text = "Thêm Mã Hàng";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnAddMaHang_Click);
            // 
            // txb_MaHangMoi
            // 
            this.txb_MaHangMoi.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_MaHangMoi.Location = new System.Drawing.Point(467, 479);
            this.txb_MaHangMoi.Name = "txb_MaHangMoi";
            this.txb_MaHangMoi.Size = new System.Drawing.Size(219, 32);
            this.txb_MaHangMoi.TabIndex = 88;
            this.txb_MaHangMoi.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(298, 482);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(163, 27);
            this.label42.TabIndex = 71;
            this.label42.Text = "Mã Hàng Mới:";
            this.label42.Visible = false;
            // 
            // grSpec
            // 
            this.grSpec.Controls.Add(this.button1);
            this.grSpec.Controls.Add(this.Chb_ChekcMau);
            this.grSpec.Controls.Add(this.label41);
            this.grSpec.Controls.Add(this.btSavespec);
            this.grSpec.Controls.Add(this.cbSodiemdo);
            this.grSpec.Controls.Add(this.label2);
            this.grSpec.Controls.Add(this.cbSellectMax_Min);
            this.grSpec.Controls.Add(this.tbMax_Min);
            this.grSpec.Controls.Add(this.label1);
            this.grSpec.Controls.Add(this.tbSpecMinD3);
            this.grSpec.Controls.Add(this.tbSpecMaxD3);
            this.grSpec.Controls.Add(this.label25);
            this.grSpec.Controls.Add(this.label26);
            this.grSpec.Controls.Add(this.label27);
            this.grSpec.Controls.Add(this.tbSpecMinD2);
            this.grSpec.Controls.Add(this.tbSpecMaxD2);
            this.grSpec.Controls.Add(this.label22);
            this.grSpec.Controls.Add(this.label23);
            this.grSpec.Controls.Add(this.label24);
            this.grSpec.Controls.Add(this.tbSpecMinD1);
            this.grSpec.Controls.Add(this.tbSpecMaxD1);
            this.grSpec.Controls.Add(this.label12);
            this.grSpec.Controls.Add(this.label20);
            this.grSpec.Controls.Add(this.label21);
            this.grSpec.Location = new System.Drawing.Point(292, 140);
            this.grSpec.Name = "grSpec";
            this.grSpec.Size = new System.Drawing.Size(1269, 306);
            this.grSpec.TabIndex = 70;
            this.grSpec.TabStop = false;
            this.grSpec.Text = "Tiêu Chuẩn Đánh Giá";
            // 
            // Chb_ChekcMau
            // 
            this.Chb_ChekcMau.AutoSize = true;
            this.Chb_ChekcMau.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chb_ChekcMau.Location = new System.Drawing.Point(215, 244);
            this.Chb_ChekcMau.Name = "Chb_ChekcMau";
            this.Chb_ChekcMau.Size = new System.Drawing.Size(15, 14);
            this.Chb_ChekcMau.TabIndex = 87;
            this.Chb_ChekcMau.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(52, 241);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(134, 22);
            this.label41.TabIndex = 86;
            this.label41.Text = "Đo Check Mẫu";
            // 
            // btSavespec
            // 
            this.btSavespec.BackColor = System.Drawing.Color.Blue;
            this.btSavespec.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSavespec.ForeColor = System.Drawing.Color.Transparent;
            this.btSavespec.Location = new System.Drawing.Point(1098, 231);
            this.btSavespec.Name = "btSavespec";
            this.btSavespec.Size = new System.Drawing.Size(165, 69);
            this.btSavespec.TabIndex = 76;
            this.btSavespec.Text = "Lưu Cài Đặt";
            this.btSavespec.UseVisualStyleBackColor = false;
            this.btSavespec.Click += new System.EventHandler(this.btSavespec_Click);
            // 
            // cbSodiemdo
            // 
            this.cbSodiemdo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSodiemdo.FormattingEnabled = true;
            this.cbSodiemdo.Location = new System.Drawing.Point(215, 198);
            this.cbSodiemdo.Name = "cbSodiemdo";
            this.cbSodiemdo.Size = new System.Drawing.Size(128, 25);
            this.cbSodiemdo.TabIndex = 77;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 200);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 22);
            this.label2.TabIndex = 85;
            this.label2.Text = "Số Điểm Đo:";
            // 
            // cbSellectMax_Min
            // 
            this.cbSellectMax_Min.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSellectMax_Min.Location = new System.Drawing.Point(349, 149);
            this.cbSellectMax_Min.Name = "cbSellectMax_Min";
            this.cbSellectMax_Min.Size = new System.Drawing.Size(20, 25);
            this.cbSellectMax_Min.TabIndex = 84;
            this.cbSellectMax_Min.UseVisualStyleBackColor = true;
            this.cbSellectMax_Min.CheckedChanged += new System.EventHandler(this.cbSellectMax_Min_CheckedChanged_1);
            // 
            // tbMax_Min
            // 
            this.tbMax_Min.Location = new System.Drawing.Point(215, 154);
            this.tbMax_Min.Name = "tbMax_Min";
            this.tbMax_Min.Size = new System.Drawing.Size(128, 25);
            this.tbMax_Min.TabIndex = 83;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 22);
            this.label1.TabIndex = 82;
            this.label1.Text = "Max - Min:";
            // 
            // tbSpecMinD3
            // 
            this.tbSpecMinD3.Location = new System.Drawing.Point(1081, 108);
            this.tbSpecMinD3.Name = "tbSpecMinD3";
            this.tbSpecMinD3.Size = new System.Drawing.Size(128, 25);
            this.tbSpecMinD3.TabIndex = 81;
            // 
            // tbSpecMaxD3
            // 
            this.tbSpecMaxD3.Location = new System.Drawing.Point(1081, 66);
            this.tbSpecMaxD3.Name = "tbSpecMaxD3";
            this.tbSpecMaxD3.Size = new System.Drawing.Size(128, 25);
            this.tbSpecMaxD3.TabIndex = 80;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(906, 27);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(106, 22);
            this.label25.TabIndex = 77;
            this.label25.Text = "Điểm Đo 3:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(906, 65);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(131, 22);
            this.label26.TabIndex = 78;
            this.label26.Text = "Giới Hạn Trên:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(906, 110);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(136, 22);
            this.label27.TabIndex = 79;
            this.label27.Text = "Giới Hạn Dưới:";
            // 
            // tbSpecMinD2
            // 
            this.tbSpecMinD2.Location = new System.Drawing.Point(645, 108);
            this.tbSpecMinD2.Name = "tbSpecMinD2";
            this.tbSpecMinD2.Size = new System.Drawing.Size(128, 25);
            this.tbSpecMinD2.TabIndex = 76;
            // 
            // tbSpecMaxD2
            // 
            this.tbSpecMaxD2.Location = new System.Drawing.Point(645, 66);
            this.tbSpecMaxD2.Name = "tbSpecMaxD2";
            this.tbSpecMaxD2.Size = new System.Drawing.Size(128, 25);
            this.tbSpecMaxD2.TabIndex = 75;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(473, 30);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(106, 22);
            this.label22.TabIndex = 72;
            this.label22.Text = "Điểm Đo 2:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(473, 68);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(131, 22);
            this.label23.TabIndex = 73;
            this.label23.Text = "Giới Hạn Trên:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(473, 113);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(136, 22);
            this.label24.TabIndex = 74;
            this.label24.Text = "Giới Hạn Dưới:";
            // 
            // tbSpecMinD1
            // 
            this.tbSpecMinD1.Location = new System.Drawing.Point(215, 108);
            this.tbSpecMinD1.Name = "tbSpecMinD1";
            this.tbSpecMinD1.Size = new System.Drawing.Size(128, 25);
            this.tbSpecMinD1.TabIndex = 71;
            // 
            // tbSpecMaxD1
            // 
            this.tbSpecMaxD1.Location = new System.Drawing.Point(215, 66);
            this.tbSpecMaxD1.Name = "tbSpecMaxD1";
            this.tbSpecMaxD1.Size = new System.Drawing.Size(128, 25);
            this.tbSpecMaxD1.TabIndex = 70;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(50, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(106, 22);
            this.label12.TabIndex = 52;
            this.label12.Text = "Điểm Đo 1:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(50, 66);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(131, 22);
            this.label20.TabIndex = 68;
            this.label20.Text = "Giới Hạn Trên:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(50, 111);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(136, 22);
            this.label21.TabIndex = 69;
            this.label21.Text = "Giới Hạn Dưới:";
            // 
            // cbMahangSet
            // 
            this.cbMahangSet.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbMahangSet.FormattingEnabled = true;
            this.cbMahangSet.Location = new System.Drawing.Point(409, 83);
            this.cbMahangSet.Name = "cbMahangSet";
            this.cbMahangSet.Size = new System.Drawing.Size(356, 32);
            this.cbMahangSet.TabIndex = 67;
            this.cbMahangSet.SelectedIndexChanged += new System.EventHandler(this.cbMahangSet_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(288, 87);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 27);
            this.label11.TabIndex = 51;
            this.label11.Text = "Mã Hàng:";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.btSaveST);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox6);
            this.tabPage1.Controls.Add(this.grb_PLC);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1875, 881);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Setup";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(815, 83);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(205, 27);
            this.label19.TabIndex = 69;
            this.label19.Text = "CÀI ĐẶT KẾT NỐI";
            // 
            // btSaveST
            // 
            this.btSaveST.BackColor = System.Drawing.Color.Blue;
            this.btSaveST.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSaveST.ForeColor = System.Drawing.Color.Transparent;
            this.btSaveST.Location = new System.Drawing.Point(1182, 633);
            this.btSaveST.Name = "btSaveST";
            this.btSaveST.Size = new System.Drawing.Size(165, 69);
            this.btSaveST.TabIndex = 74;
            this.btSaveST.Text = "Lưu Cài Đặt";
            this.btSaveST.UseVisualStyleBackColor = false;
            this.btSaveST.Click += new System.EventHandler(this.btSaveST_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cbBaudrateR3);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.cbComR3);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(932, 440);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(415, 118);
            this.groupBox4.TabIndex = 73;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Đầu Đo R3";
            // 
            // cbBaudrateR3
            // 
            this.cbBaudrateR3.FormattingEnabled = true;
            this.cbBaudrateR3.Location = new System.Drawing.Point(211, 72);
            this.cbBaudrateR3.Name = "cbBaudrateR3";
            this.cbBaudrateR3.Size = new System.Drawing.Size(156, 26);
            this.cbBaudrateR3.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(37, 73);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 22);
            this.label8.TabIndex = 67;
            this.label8.Text = "Baudrate:";
            // 
            // cbComR3
            // 
            this.cbComR3.FormattingEnabled = true;
            this.cbComR3.Location = new System.Drawing.Point(211, 27);
            this.cbComR3.Name = "cbComR3";
            this.cbComR3.Size = new System.Drawing.Size(156, 26);
            this.cbComR3.TabIndex = 66;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(37, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 22);
            this.label9.TabIndex = 65;
            this.label9.Text = "Cổng Kết Nối:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbBaudrateL3);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.cbComL3);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Location = new System.Drawing.Point(478, 440);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(415, 118);
            this.groupBox3.TabIndex = 70;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Đầu Đo L3";
            // 
            // cbBaudrateL3
            // 
            this.cbBaudrateL3.FormattingEnabled = true;
            this.cbBaudrateL3.Location = new System.Drawing.Point(211, 72);
            this.cbBaudrateL3.Name = "cbBaudrateL3";
            this.cbBaudrateL3.Size = new System.Drawing.Size(156, 26);
            this.cbBaudrateL3.TabIndex = 68;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(37, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 22);
            this.label6.TabIndex = 67;
            this.label6.Text = "Baudrate:";
            // 
            // cbComL3
            // 
            this.cbComL3.FormattingEnabled = true;
            this.cbComL3.Location = new System.Drawing.Point(211, 27);
            this.cbComL3.Name = "cbComL3";
            this.cbComL3.Size = new System.Drawing.Size(156, 26);
            this.cbComL3.TabIndex = 66;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(37, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 22);
            this.label7.TabIndex = 65;
            this.label7.Text = "Cổng Kết Nối:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cbBaudrateR2);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.cbComR2);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Location = new System.Drawing.Point(932, 291);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(415, 118);
            this.groupBox5.TabIndex = 72;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Đầu Đo R2";
            // 
            // cbBaudrateR2
            // 
            this.cbBaudrateR2.FormattingEnabled = true;
            this.cbBaudrateR2.Location = new System.Drawing.Point(211, 72);
            this.cbBaudrateR2.Name = "cbBaudrateR2";
            this.cbBaudrateR2.Size = new System.Drawing.Size(156, 26);
            this.cbBaudrateR2.TabIndex = 68;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(37, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(91, 22);
            this.label10.TabIndex = 67;
            this.label10.Text = "Baudrate:";
            // 
            // cbComR2
            // 
            this.cbComR2.FormattingEnabled = true;
            this.cbComR2.Location = new System.Drawing.Point(211, 26);
            this.cbComR2.Name = "cbComR2";
            this.cbComR2.Size = new System.Drawing.Size(156, 26);
            this.cbComR2.TabIndex = 66;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(37, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(128, 22);
            this.label16.TabIndex = 65;
            this.label16.Text = "Cổng Kết Nối:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbBaudrateL2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.cbComL2);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(478, 291);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(415, 118);
            this.groupBox2.TabIndex = 69;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Đầu Đo L2";
            // 
            // cbBaudrateL2
            // 
            this.cbBaudrateL2.FormattingEnabled = true;
            this.cbBaudrateL2.Location = new System.Drawing.Point(211, 72);
            this.cbBaudrateL2.Name = "cbBaudrateL2";
            this.cbBaudrateL2.Size = new System.Drawing.Size(156, 26);
            this.cbBaudrateL2.TabIndex = 68;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 22);
            this.label3.TabIndex = 67;
            this.label3.Text = "Baudrate:";
            // 
            // cbComL2
            // 
            this.cbComL2.FormattingEnabled = true;
            this.cbComL2.Location = new System.Drawing.Point(211, 26);
            this.cbComL2.Name = "cbComL2";
            this.cbComL2.Size = new System.Drawing.Size(156, 26);
            this.cbComL2.TabIndex = 66;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 22);
            this.label4.TabIndex = 65;
            this.label4.Text = "Cổng Kết Nối:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.cbBaudrateR1);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.cbComR1);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Location = new System.Drawing.Point(932, 150);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(415, 118);
            this.groupBox6.TabIndex = 71;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Đầu Đo R1";
            // 
            // cbBaudrateR1
            // 
            this.cbBaudrateR1.FormattingEnabled = true;
            this.cbBaudrateR1.Location = new System.Drawing.Point(211, 72);
            this.cbBaudrateR1.Name = "cbBaudrateR1";
            this.cbBaudrateR1.Size = new System.Drawing.Size(156, 26);
            this.cbBaudrateR1.TabIndex = 68;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(37, 73);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(91, 22);
            this.label17.TabIndex = 67;
            this.label17.Text = "Baudrate:";
            // 
            // cbComR1
            // 
            this.cbComR1.FormattingEnabled = true;
            this.cbComR1.Location = new System.Drawing.Point(211, 26);
            this.cbComR1.Name = "cbComR1";
            this.cbComR1.Size = new System.Drawing.Size(156, 26);
            this.cbComR1.TabIndex = 66;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(37, 30);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(128, 22);
            this.label18.TabIndex = 65;
            this.label18.Text = "Cổng Kết Nối:";
            // 
            // grb_PLC
            // 
            this.grb_PLC.Controls.Add(this.btCheckconnect);
            this.grb_PLC.Controls.Add(this.tbPortplc);
            this.grb_PLC.Controls.Add(this.tbIPplc);
            this.grb_PLC.Controls.Add(this.label15);
            this.grb_PLC.Controls.Add(this.label14);
            this.grb_PLC.Location = new System.Drawing.Point(478, 604);
            this.grb_PLC.Name = "grb_PLC";
            this.grb_PLC.Size = new System.Drawing.Size(598, 125);
            this.grb_PLC.TabIndex = 66;
            this.grb_PLC.TabStop = false;
            this.grb_PLC.Text = "PLC";
            // 
            // btCheckconnect
            // 
            this.btCheckconnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btCheckconnect.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCheckconnect.ForeColor = System.Drawing.Color.Transparent;
            this.btCheckconnect.Location = new System.Drawing.Point(433, 44);
            this.btCheckconnect.Name = "btCheckconnect";
            this.btCheckconnect.Size = new System.Drawing.Size(149, 48);
            this.btCheckconnect.TabIndex = 75;
            this.btCheckconnect.Text = "K.Tra Kết Nối";
            this.btCheckconnect.UseVisualStyleBackColor = false;
            this.btCheckconnect.Click += new System.EventHandler(this.btCheckconnect_Click);
            // 
            // tbPortplc
            // 
            this.tbPortplc.Location = new System.Drawing.Point(218, 77);
            this.tbPortplc.Name = "tbPortplc";
            this.tbPortplc.Size = new System.Drawing.Size(168, 26);
            this.tbPortplc.TabIndex = 71;
            // 
            // tbIPplc
            // 
            this.tbIPplc.Location = new System.Drawing.Point(218, 29);
            this.tbIPplc.Name = "tbIPplc";
            this.tbIPplc.Size = new System.Drawing.Size(168, 26);
            this.tbIPplc.TabIndex = 70;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(37, 76);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 22);
            this.label15.TabIndex = 69;
            this.label15.Text = "Cổng:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(37, 32);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(143, 22);
            this.label14.TabIndex = 68;
            this.label14.Text = "Địa Chỉ IP PLC:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbBaudrateL1);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.cbComL1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(478, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(415, 118);
            this.groupBox1.TabIndex = 65;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Đầu Đo L1";
            // 
            // cbBaudrateL1
            // 
            this.cbBaudrateL1.FormattingEnabled = true;
            this.cbBaudrateL1.Location = new System.Drawing.Point(211, 72);
            this.cbBaudrateL1.Name = "cbBaudrateL1";
            this.cbBaudrateL1.Size = new System.Drawing.Size(156, 26);
            this.cbBaudrateL1.TabIndex = 68;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(37, 71);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(91, 22);
            this.label13.TabIndex = 67;
            this.label13.Text = "Baudrate:";
            // 
            // cbComL1
            // 
            this.cbComL1.FormattingEnabled = true;
            this.cbComL1.Location = new System.Drawing.Point(211, 26);
            this.cbComL1.Name = "cbComL1";
            this.cbComL1.Size = new System.Drawing.Size(156, 26);
            this.cbComL1.TabIndex = 66;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(37, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 22);
            this.label5.TabIndex = 65;
            this.label5.Text = "Cổng Kết Nối:";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.label40);
            this.panel2.Location = new System.Drawing.Point(1, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1883, 52);
            this.panel2.TabIndex = 138;
            // 
            // label40
            // 
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Arial", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(0, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(1883, 52);
            this.label40.TabIndex = 102;
            this.label40.Text = "MÁY ĐO ĐỘ CỨNG";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmDDC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tabSelect);
            this.KeyPreview = true;
            this.Name = "frmDDC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Máy Đo Độ Cứng";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmDDC_FormClosing);
            this.Load += new System.EventHandler(this.frmDDC_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.tabSelect.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabSpec.ResumeLayout(false);
            this.tabSpec.PerformLayout();
            this.grSpec.ResumeLayout(false);
            this.grSpec.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.grb_PLC.ResumeLayout(false);
            this.grb_PLC.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage tabMain;
        private System.Windows.Forms.TabPage tabSpec;
        private System.Windows.Forms.TabControl tabSelect;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox grb_PLC;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbComL1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbPortplc;
        private System.Windows.Forms.TextBox tbIPplc;
        private System.Windows.Forms.ComboBox cbBaudrateL1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cbBaudrateR3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbComR3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cbBaudrateL3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbComL3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox cbBaudrateR2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbComR2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cbBaudrateL2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbComL2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox cbBaudrateR1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cbComR1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btSaveST;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox grSpec;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cbMahangSet;
        private System.Windows.Forms.TextBox tbSpecMinD1;
        private System.Windows.Forms.TextBox tbSpecMaxD1;
        private System.Windows.Forms.Button btCheckconnect;
        private System.Windows.Forms.TextBox tbSpecMinD2;
        private System.Windows.Forms.TextBox tbSpecMaxD2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tbSpecMinD3;
        private System.Windows.Forms.TextBox tbSpecMaxD3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbKetquaL3;
        private System.Windows.Forms.TextBox tbKetquaL2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbKetquaL1;
        private System.Windows.Forms.ComboBox cbMahangrun;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lbKetquaR;
        private System.Windows.Forms.Label lbKetquaL;
        private System.Windows.Forms.TextBox tbKetquaR3;
        private System.Windows.Forms.TextBox tbKetquaR2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox tbKetquaR1;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox tbTrungbinhR;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox tbTrungbinhL;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox NGMaxMin;
        private System.Windows.Forms.TextBox tbNG;
        private System.Windows.Forms.TextBox tbOk;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.ComboBox cbLot;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button btSavespec;
        private System.Windows.Forms.Label lbDD1status;
        private System.Windows.Forms.Label lbPLCstatus;
        private System.Windows.Forms.Label lbDD6status;
        private System.Windows.Forms.Label lbDD5status;
        private System.Windows.Forms.Label lbDD4status;
        private System.Windows.Forms.Label lbDD3status;
        private System.Windows.Forms.Label lbDD2status;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox tbMinD3_Main;
        private System.Windows.Forms.TextBox tbMaxD3_Main;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox tbMinD2_Main;
        private System.Windows.Forms.TextBox tbMaxD2_Main;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox tbMinD1_Main;
        private System.Windows.Forms.TextBox tbMaxD1_Main;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label lbKq_L3;
        private System.Windows.Forms.Label lbKq_L2;
        private System.Windows.Forms.Label lbKq_L1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btTest;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label lbKq_R3;
        private System.Windows.Forms.Label lbKq_R2;
        private System.Windows.Forms.Label lbKq_R1;
        private System.Windows.Forms.TextBox tbMax_Min;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbSellectMax_Min;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbSodiemdo;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckBox Chb_ChekcMau;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txb_MaHangMoi;
        private System.Windows.Forms.Label label42;
    }
}

